var express = require('express');
var router = express.Router();
var db = require('../models/database');
router.get('/', function(req, res, next) {
    let sql = `SELECT * FROM loaisanpham`;
    db.query(sql, function(err, data) {      
        res.render("loai",{list:data});    
    });
});
router.get('/addnew', function(req, res, next) {
    res.send('Form thêm loại sách'); 
});
router.post('/store', function(req, res, next) {
    //nhận dữ liệu từ addnew để thêm record vào db
});
router.get('/edit/:id', function(req, res, next) {
  var id = req.params.id;
  res.send('Form chỉnh loại sách' + id);
});
router.post('/update', function(req, res, next) {
    //nhận dữ liệu từ edit để cập nhật vào db
});
router.get('/delete/:id', function(req, res) {
  var id = req.params.id;
  res.send('Xóa loai');
});

module.exports = router;