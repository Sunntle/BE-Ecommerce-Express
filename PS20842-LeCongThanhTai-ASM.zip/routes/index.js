var express = require('express');
var router = express.Router();
var db = require('../models/database');
/* GET home page. */
router.get('/', function(req, res, next) {
  let sql = `SELECT tenLoai FROM loaisanpham`;
  let sqlBanner = `SELECT * FROM slide`;
  let sqlItemBestSeller = `SELECT * FROM sanpham ORDER BY sold DESC LIMIT 4`
  let sqlItemNew = `SELECT * FROM sanpham ORDER BY date DESC LIMIT 4`
    db.query(sql, function(err, data) {   
      if(err) throw err; 
      db.query(sqlBanner,function(err, banners) {   
        if(err) throw err; 
        db.query(sqlItemBestSeller,function(err, itemBestSeller) {   
          if(err) throw err; 
          db.query(sqlItemNew,function(err, itemNew) {   
            if(err) throw err; 
          res.render('index',{categories:data,banners: banners,itemBestSeller: itemBestSeller,itemNew:itemNew}); 
          })   
        })   
      }) 
    });
});

module.exports = router;
